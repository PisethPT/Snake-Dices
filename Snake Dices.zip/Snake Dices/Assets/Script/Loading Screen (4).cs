using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LoadingScreen : MonoBehaviour
{
    public GameObject sliderObjec;
    bool isAction = true;
    float time = 0;

    private void Update()
    {
        if (isAction)
        {
            time += 0.1f;
            sliderObjec.transform.GetChild(0).GetComponent<Image>().fillAmount += time;
            
            if(time >= 1)
            {
                gameObject.SetActive(false);

            }
            if (time <= 1)
            {
                StartCoroutine(wait());

            }
            isAction = false;
            
        }
    }
    IEnumerator wait()
    {
        yield return new WaitForSeconds(0.2f);
        isAction = true;
        
    }
}
