using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SnakeScript : MonoBehaviour
{
    [Header("Lists & Arrays")]
    public  List<int> dice_List = new List<int>();
    public  List<int> numbers_List = new List<int>();
    public List<Text> textsBlock = new List<Text>();
    public Sprite[] diecSprite;
    public Image[] diecImages;
    public GameObject[] imojis;
    private bool isOnClick, isTimer;
    int dice_1, dice_2, dice_3, dice_4, dice_5, dice_6;
    int sumDice = 0, count = 31, winCount = 0, disableButtonIndex ;
    float countTime = 10f;
    [Header("Texts")]
    public Text result;
    public Text number;
    public Text countTimer;

    [Header("Objects")]
    public Animator animator;
    public GameObject Snake;
    public Button shuffleButton;

    [Header("Timer Circle Slider")]
    public Slider circleTiime;

    [Header("List Panel")]
    public List<Sprite> panelSprites;
    public GameObject panel;


    private void Start()
    {
        FindAnyObjectByType<Audios>().music.Play();
        for(int i = 0; i < imojis.Length; i++)
            imojis[i].SetActive(false);
        RandomNumberLists();
        GetTextIntoButton();
    }

    private void Update()
    {
        if (isOnClick)
        {
            animator.Play("idle");
            RandomDieces();
            isOnClick = false;
        }
        if (isTimer)
        {
            countTime -= Time.deltaTime;
            circleTiime.value = countTime;
            countTimer.text = Mathf.Round(countTime).ToString();
            if (countTime <= 0)
            {
                result.text = "0";
                sumDice = 0;
                CaluculatorWinAndLose();
                isTimer = false;
               // Snake.transform.GetChild(disableButtonIndex).GetComponent<Button>().enabled = false;
            }
        }
    }

    public void ButtonOnclick()
    {
        FindObjectOfType<Audios>().sfxSources[0].Play();
        isTimer = false;
        animator.Play("controller");
        isOnClick = true;
        isTimer = true;
        countTime = 10f;
        circleTiime.value = countTime;
        count--;
        print(count);
        if (count <= 0)
        {
            shuffleButton.enabled = false;
            shuffleButton.GetComponent<Image>().color = Color.gray;
        }
        number.text = count.ToString();
        
    }

    // random dieces

    public void RandomNumberLists()
    {
        for (int i = 0; i < 31; i++)
        {
            int number = Random.Range(6, 37);
            while (numbers_List.Contains(number))
                number = Random.Range(6, 37);
                numbers_List.Add(number);
        }
    }

    public void GetSpriteDiecs(int dieceNumber, int diceLocate)
    {
        for(int i = 0; i < diecSprite.Length; i++)
        {
            if(i == dieceNumber - 1)
            {
                diecImages[diceLocate].sprite = diecSprite[i];
            }
            
        }
    }
    public void RandomDieces()
    {
        if (count >= 0)
        {
            for (int i = 0; i < 1; i++)
            {
                dice_1 = Random.Range(1, 7);
                dice_2 = Random.Range(1, 7);
                dice_3 = Random.Range(1, 7);
                dice_4 = Random.Range(1, 7);
                dice_5 = Random.Range(1, 7);
                dice_6 = Random.Range(1, 7);

                sumDice = dice_1 + dice_2 + dice_3 + dice_4 + dice_5 + dice_6;
                while (dice_List.Contains(sumDice))
                {
                    dice_1 = Random.Range(1, 7);
                    dice_2 = Random.Range(1, 7);
                    dice_3 = Random.Range(1, 7);
                    dice_4 = Random.Range(1, 7);
                    dice_5 = Random.Range(1, 7);
                    dice_6 = Random.Range(1, 7);
                    sumDice = dice_1 + dice_2 + dice_3 + dice_4 + dice_5 + dice_6;
                }
                dice_List.Add(sumDice);

            }
            result.text = sumDice.ToString();
            GetSpriteDiecs(dice_1, 0);
            GetSpriteDiecs(dice_2, 1);
            GetSpriteDiecs(dice_3, 2);
            GetSpriteDiecs(dice_4, 3);
            GetSpriteDiecs(dice_5, 4);
            GetSpriteDiecs(dice_6, 5);
        }
    }

    public void GetTextIntoButton()
    {
        for (int i = 0; i < numbers_List.Count; i++)
        {
            textsBlock[i].text = numbers_List[i].ToString();
        }
    }

    int blockNumber;
    public void BlockClick(int n)
    {
        FindObjectOfType<Audios>().sfxSources[0].Play();
        disableButtonIndex = n+1;
        blockNumber = int.Parse(textsBlock[n].GetComponent<Text>().text);
        if (blockNumber.Equals(sumDice))
        {
            imojis[n].SetActive(true);
            isTimer = false;
          // print($"{n}: {textsBlock[n].GetComponent<Text>().text}, sum: {sumDice}");
           // Snake.transform.GetChild(n+1).GetComponent<SpriteRenderer>().color = Color.gray;
            Snake.transform.GetChild(n+1).GetComponent<Button>().enabled = false;
            winCount++;
            print(winCount);
        }
       CaluculatorWinAndLose();
    }


    public void CaluculatorWinAndLose()
    {
        if (winCount.Equals(Snake.transform.childCount - 2) && count.Equals(0))
        {
            for (int i = 0; i < imojis.Length; i++)
                imojis[i].SetActive(false);
            FindObjectOfType<Audios>().sfxSources[1].Play();
            print("Win!!");
            isTimer = false;
            panel.SetActive(true);
            panel.GetComponent<Image>().sprite = panelSprites[0];
        }
        else if(count.Equals(0) && winCount < Snake.transform.childCount-2)
        {
            for (int i = 0; i < imojis.Length; i++)
                imojis[i].SetActive(false);
            FindObjectOfType<Audios>().sfxSources[2].Play();
            print("Lose.");
            isTimer = false;
            panel.SetActive(true);
            panel.GetComponent<Image>().sprite = panelSprites[1];
        }
    }

    public void closeButton()
    {
        FindObjectOfType<Audios>().sfxSources[0].Play();
        SceneManager.LoadScene(1);
    }
    public void replayButton()
    {
        FindObjectOfType<Audios>().sfxSources[0].Play();
        SceneManager.LoadScene(1);
    }

    public void callingHome()
    {
        FindObjectOfType<Audios>().sfxSources[0].Play();
        SceneManager.LoadScene(0);
    }
    
}
