using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Audios : MonoBehaviour
{
    [Header("SFX Sources")]
    public AudioSource[] sfxSources;
    [Header("Music Source")]
    public AudioSource music;
    public Sprite[] sprites;
    public Button musicButton;
    bool isMusic = true;

    public void controllerMusic()
    {
        sfxSources[0].Play();
        isMusic = !isMusic;
        if (isMusic)
        {
            music.Play();
            music.mute = false;
            musicButton.image.sprite = sprites[0];
        }else if (!isMusic)
        {
            music.Play();
            music.mute = true;
            musicButton.image.sprite = sprites[1];
        }
    }
}
